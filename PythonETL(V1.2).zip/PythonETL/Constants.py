class PersonDict(object):
    GENDER={
        "F": 8532,
        "M": 8507,
        "U": 8551
    }
    RACE={
        "AMERICAN INDIAN OR ALASKA NATIVE": 8657,
        "ASIAN": 8515,
        "BLACK OR AFRICAN AMERICAN": 8516,
        "NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER": 8557,
        "WHITE": 8527,
        "UNKNOWN/UNAVAILABLE": 8552,
        "HISPANIC":4188159
    }
class DeathDict:
    DEATHTYPE={
       "Unrelated to Disease":173000,
       "Unrelated to Cancer but with Disease":173003,
       "Unknown cause but with Disease":173002,
       "Secondary Primary Cancer":173004,
       "Complications of Treatment":173001,
       "Primary Cancer":4312326,
       "Unknown cause and unknown Disease Status":441413
    }
class CaresiteDict:

    PLACEOFSERVICE={
        "School": 8537,
        "Pharmacy": 8562,
        "Temporary Lodging": 8602,
        "Birthing Center": 8650,
        "Homeless Shelter": 8672,
        "Outpatient NEC": 8677,
        "Inpatient Hospital": 8717,
        "Rural Health Clinic": 8761,
        "Urgent Care Facility": 8782,
        "Custodial Care Facility": 8827,
        "Ambulance - Air or Water": 8850,
        "Mass Immunization Center": 8858,
        "Emergency Room - Hospital": 8870,
        "Ambulatory Surgical Center": 8883,
        "Military Treatment Facility": 8905,
        "Comprehensive Inpatient Rehabilitation Facility": 8920,
        "Tribal 638 Free-standing Facility": 8941,
        "End-Stage Renal Disease Treatment Facility": 8949,
        "Residential Substance Abuse Treatment Facility": 8957,
        "Community Mental Health Center": 8964,
        "Indian Health Service Free-standing Facility": 8968,
        "Inpatient Long-term Care": 8970,
        "Non-residential Substance Abuse Treatment Facility": 8974,
        "Public Health Clinic": 8977,
        "Walk-in Retail Health Clinic": 38003620,
        "Home": 8536,
        "Hospice": 8546,
        "Mobile Unit": 8584,
        "Assisted Living Facility": 8615,
        "Ambulance - Land": 8668,
        "Nursing Facility": 8676,
        "Independent Clinic": 8716,
        "Outpatient Hospital": 8756,
        "Independent Laboratory": 8809,
        "Other Place of Service": 8844,
        "Group Home": 8851,
        "Skilled Nursing Facility": 8863,
        "Adult Living Care Facility": 8882,
        "Other Inpatient Care": 8892,
        "Psychiatric Facility-Partial Hospitalization": 8913,
        "Office": 8940,
        "Comprehensive Outpatient Rehabilitation Facility": 8947,
        "Intermediate Care Facility/Mentally Retarded": 8951,
        "Tribal 638 Provider-based Facility": 8960,
        "Federally Qualified Health Center": 8966,
        "Indian Health Service Provider-based Facility": 8969,
        "Inpatient Psychiatric Facility": 8971,
        "Psychiatric Residential Treatment Center": 8976,
        "Prison/Correctional Facility": 38003619,
        "Telehealth": 5083,
        "Inpatient Critical Care Facility": 581379,
        "Emergency Room Critical Care Facility": 581381,
        "Inpatient Cardiac Care Facility": 581383,
        "Observation Room": 581385,
        "Interactive Telemedicine Service": 581399,
        "Off Campus-Outpatient Hospital": 5084,
        "Outpatient Critical Care Facility": 581380,
        "Inpatient Intensive Care Facility": 581382,
        "Inpatient Nursery": 581384,
        "Place of Employment-Worksite": 581475
    }
class ObservationDict:
    TREAMMENTlINE={
        "Adjuvant":40272698,
        "1st Line":45769570,
        "2nd Line":45769571,
        "3rd Line":45769572
    }
class VisitOccurenceDict:

    VISITTYPE={
        "Chemotherapy":4273629,
        "Radiation":4220084
    }
class ConditionOccurrenceDict:
    CONDITION={
        "C186": 443382,
        "C180": 443391,
        "C183": 4180791,
        "C184": 443384,
        "C181": 443383,
        "C199": 4180792,
        "C187": 443381,
        "C182": 435754,
        "C185": 4181344
    }
    SITE={
        "Soft Tissue":100000,
        "Lung":100001,
        "Local/Regional":100002,
        "Liver": 100003,
        "Bone": 100004,
        "CNS": 100005,
        "Lymph Nodes": 100006,
        "Other": 100007

    }
class ProcedureOccurrenceDict:
    TREAMMENTTYPE={
        "Chemotherapy":4273629,
        "Radiation":4220084
    }
class MeasurementDict:
   T_DSC={
       "T2":45884279,
       "T3":45876313,
       "T4a":45881604,
       "T4b":45880976
   }
   N_DSC={
       "N2":5881614,
       "N2b": 45880111,
       "N2a": 45882498,
       "N1": 45881613,
       "N1b": 45881615,
       "N1a": 45880982,
       "N1c": 46237062
   }
   M_DSC={
       "MX":45876323
   }
   M_CLIN_DSC={
       "M0":45878650
   }
class VariantOccurrenceDict:
    TYPE = {
        "MSI": 172012,
        "PMS2": 172017,
        "MSH6": 172011,
        "MLH1": 172009,
        "BRAF": 172002,
        "EGFR": 172003,
        "PIK3CA": 172016,
        "KRAS": 172008,
        "MSH2": 172010,
        "NARS": 172013
    }
class DrugExposureDict:
    Drug={
        "FOLFOX":173005,
        "Bevacizumab":173006,
        "Capecitabine":173007,
        "Erbitux":173008,
        "Irinotecan Hydrochloride":173009,
        "Oxaliplatin":173010,
        "Cetuximab":173011,
        "Panitumumab":173012,
        "FOLFIRI":173013,
        "Fluorouracil":173014,
        "Stivarga":173015,
        "Mitomycin C":173016,
        "Other Specified Antibiotics":173010,
        "External Beam":"Unknown"

    }